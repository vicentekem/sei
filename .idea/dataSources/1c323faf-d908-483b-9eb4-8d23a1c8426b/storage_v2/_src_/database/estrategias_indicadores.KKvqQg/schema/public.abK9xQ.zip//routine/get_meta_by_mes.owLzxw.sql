CREATE FUNCTION get_meta_by_mes(id_meta integer, nro_mes integer)
  RETURNS numeric
LANGUAGE plpgsql
AS $$
DECLARE 
		cant_reg INTEGER := 0;
		result_avance decimal(5,2) := 0;
    BEGIN
		
		select  count(*) INTO cant_reg from vacuna_general where meta = id_meta and mes = nro_mes;
			
		if cant_reg > 0 then 		
				select sum( avance_mensual ) INTO result_avance from vacuna_general vg
				inner join meta me on me.id = vg.meta
				where me.id = id_meta and vg.mes = nro_mes;			
		else
			result_avance = null;
		end if;
		
		return result_avance;
    END;
$$;

